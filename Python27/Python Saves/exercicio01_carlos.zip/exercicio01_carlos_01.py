n1 = int(input('Digite o primeiro numero '))
n2 = int(input('Digite o segundo numero '))
print (n1+n2)
