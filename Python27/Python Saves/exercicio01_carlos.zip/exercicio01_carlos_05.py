preco = float(input('Digite o pre�o do produto: '))
pdesc = float(input('Digite a porcentagem de desconto: '))
desc = preco*(pdesc/100)
new = preco-desc
print('O produto com pre�o de R$',preco,' ap�s o desconto de %',pdesc,'(R$',desc,') ficou com o pre�o de R$:',new)
