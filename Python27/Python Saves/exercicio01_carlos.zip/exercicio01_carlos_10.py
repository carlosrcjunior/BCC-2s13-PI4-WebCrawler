cigarros = int(input('Quantidade de cigarros fumados por dia: '))
anos = float(input('Quantidade de anos como fumante: '))
tempo = 10*cigarros*(anos*365)
dia = int(tempo/1440)
tempo = tempo-(1440*dia)
horas = int(tempo/60)
tempo = tempo-(60*horas)
minutos = tempo
print(dia,'dias',horas,'horas',minutos,'minutos de vida perdidos')
