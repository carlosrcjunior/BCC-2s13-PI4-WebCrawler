c = float(input('Digite a temperatura: '))
f = 9*c/5+32
print('A temperatura em fahrenheit �: ',f)
