f = float(input('Digite a temperatura: '))
c = (f-32)/1.8
print('A temperatura em celsius �: ',c)
