# -*- coding: cp1252 -*-
metro = int(input('Digite um valor em metros: '))
mm = metro*1000
print(metro,'metros � igual a :',mm,'mm')
