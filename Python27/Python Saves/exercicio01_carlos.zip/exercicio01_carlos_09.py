dist = float(input('Digite a quantidade de KM percorridos: '))
dias = int(input('Digite a quantidade de dias pelos quais foi alugado: '))
preco = dias*60+dist*0.15
print('Preco a pagar R$',preco)
