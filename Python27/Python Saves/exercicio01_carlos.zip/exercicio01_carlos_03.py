dia = int(input('Digite a quantidade de dias: '))
hora = int(input('Digite a quantidade de horas: '))
minuto = int(input('Digite a quantidade de minutos: '))
segundo = int(input('Digite a quantidade de segundos: '))
minutos = minuto*60
horas = hora*3600
dias = dia * 86400
soma = dias+horas+minutos+segundo
print(dia,'dias',hora,'horas',minuto,'minutos',segundo,'segundos s�o iguais a ',soma,'segundos')
