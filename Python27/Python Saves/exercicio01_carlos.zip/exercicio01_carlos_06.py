dist = float(input('Digite a distancia da viagem(KM): '))
vm = float(input('Digite a velocidade m�dia(KM/H): '))
tempo = dist/vm
print('O tempo de viagem esperado � de :',tempo,'horas')
