n1 = len(str(2**1000000))
print (n1)
