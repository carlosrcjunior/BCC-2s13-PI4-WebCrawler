salarioi = int(input('Digite o seu sal�rio: '))
porc = float(input('Digite a porcentagem de aumento: '))
aumento = salarioi*(porc/100)
new = salarioi+aumento
print('Seu sal�rio inicial era de R$:',salarioi,'com aumento de %',porc,'(R$',aumento,') portanto seu sal�rio agora �: R$',new)
