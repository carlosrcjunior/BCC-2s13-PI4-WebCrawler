l1 = float(input('Digite o tamanho do primeiro lado do tri�ngulo: '))
l2 = float(input('Digite o tamanho do segundo lado do tri�ngulo: '))
l3 = float(input('Digite o tamanho do terceiro lado do tri�ngulo: '))
if(l1+l2>l3):
    if(l1 == l2 and l2 == l3):
        print('� um triangulo equil�tero')
        
    elif(l1 == l2 or l1 == l3 or l2 == l3):
        print('� um triangulo is�sceles')
        
    else:    
        print('� um triangulo escaleno')
        
    
else:
    print('Isso n�o � um tri�ngulo')
    
