metros = float(input('Quantidade de metros quadrados: '))
lataMetro = 3 * 18
lataPreco = 80
qtdLatas = 0
if( metros % lataMetro != 0):
    qtdLatas = int(metros/lataMetro)+1
else:
    qtdLatas = metros/lataMetro

preco = float(qtdLatas * lataPreco)
print('Voc� ir� precisar de (',qtdLatas,') lata(s) para pintar ',metros,'metro(s)�. Dando um total de: R$',preco)
