pMax = 50
Multa = 4
excesso = 0
MultaT = 0
pAtual = float(input('Digite o peso total de sua pescaria: '))
if(pAtual > pMax):
    excesso = pAtual-pMax
    MultaT = Multa*excesso
    print('Voc� excedeu o peso permitido em ',excesso,'kg e dever� pagar uma multa de R$',MultaT)
else:
    print('Voc� n�o excedeu o peso permitido')
