n1 = float(input('Digite um n�mero qualquer: '))
n2 = float(input('Digite um n�mero qualquer: '))
n3 = float(input('Digite um n�mero qualquer: '))
if (n1 >= n2) and (n1 >= n3):
    print('O Maior n�mero foi: ',n1)
elif (n2 >= n3):
    print('O Maior n�mero foi: ',n2)
else:
    print('O Maior n�mero foi: ',n3)
