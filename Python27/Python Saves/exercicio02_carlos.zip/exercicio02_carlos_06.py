hora = float(input('Quanto voc� ganha por hora? '))
horaMes = float(input('Quantas horas trabalhadas no m�s? '))
IR = 11/100
INSS = 8/100
Sindicato = 5/100
SBruto = hora * horaMes
IRDesc = SBruto * IR
INSSDesc = SBruto * INSS
SindicatoDesc = SBruto * Sindicato
SL = SBruto - IRDesc - INSSDesc - SindicatoDesc
print('+Sal�rio Bruto:R$ ',SBruto)
print('-IR(11%):R$ ',IRDesc)
print('-INSS(8%):R$ ',INSSDesc)
print('-Sindicato(5%):R$ ',SindicatoDesc)
print('=Sal�rio Liquido:R$ ',SL)
