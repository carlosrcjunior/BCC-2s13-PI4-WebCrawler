n1 = float(input('Digite um n�mero qualquer: '))
n2 = float(input('Digite um n�mero qualquer: '))
n3 = float(input('Digite um n�mero qualquer: '))
if (n1 >= n2) and (n1 >= n3):
    if(n3 <= n2):
        print('O Maior n�mero foi: ',n1,' e o menor foi: ',n3)
    elif(n3 >= n2):
        print('O Maior n�mero foi: ',n1,' e o menor foi: ',n2)
elif (n2 >= n3):
    if(n1 <= n3):
        print('O Maior n�mero foi: ',n2,' e o menor foi: ',n1)
    elif(n1>= n3):
        print('O Maior n�mero foi: ',n2,' e o menor foi: ',n3)
        
else:
    if(n1 <= n2):
        print('O Maior n�mero foi: ',n3,' e o menor foi: ',n1)
    elif(n1>=n2):
        print('O Maior n�mero foi: ',n3,' e o menor foi: ',n2)
