ano = int(input('Ano = '))
if(ano%4 == 0):
    if(str(ano).endswith('00')):
        if(ano%400 == 0):
            print('Bissexto')
        else:
            print('N�o � bissexto')
    else:
        print('Bissexto')
else:
    print('N�o � bissexto')
